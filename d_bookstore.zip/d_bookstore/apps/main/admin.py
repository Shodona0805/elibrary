from django.contrib import admin
from main.models import Book, Link, Multimedia, Software


class BookAdmin(admin.ModelAdmin):
    search_fields = ('name', 'isbn', 'author', 'published_year')
    list_display = ('name', 'isbn', 'author', 'published_year', 'is_public', 'document', 'created_at')
    list_filter = ('author', 'published_year', 'is_public', 'created_at')
    fields = ('name', 'isbn', 'author', 'published_year', 'is_public', 'document')

class LinkAdmin(admin.ModelAdmin):
    search_fields = ('name',)
    list_filter = ('is_public', 'created_at')
    list_display = ('name', 'link', 'is_public', 'created_at')
    fields = ('name', 'link', 'is_public')

class MultimediaAdmin(admin.ModelAdmin):
    search_fields = ('name',)
    fields = ('name', 'file', 'is_public')
    list_display = ('name', 'file', 'is_public', 'created_at')
    list_filter = ('is_public', 'created_at')

class SoftwareAdmin(admin.ModelAdmin):
    search_fields = ('name',)
    fields = ('name', 'file', 'is_public')
    list_display = ('name', 'file', 'is_public', 'created_at')
    list_filter = ('is_public', 'created_at')


admin.site.register(Book, BookAdmin)
admin.site.register(Link, LinkAdmin)
admin.site.register(Multimedia, MultimediaAdmin)
admin.site.register(Software, SoftwareAdmin)