import psutil
import requests


def get_filename(url):
    return url.split('/')[-1].split('?')[0]


def find_process(process_name):
    for proc in psutil.process_iter():
        for p in proc.cmdline():
            if process_name in p:
                return proc

    return False


def download_file(url, auth, folder):
    local_filename = folder + get_filename(url)
    with requests.get(url, stream=True, auth=auth) as r:
        r.raise_for_status()
        with open(local_filename, 'wb') as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

    return local_filename
