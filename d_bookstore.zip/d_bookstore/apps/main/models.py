from uuid import uuid4

from django.core.validators import FileExtensionValidator
from django.db import models
from django.utils.text import slugify


class BaseModel(models.Model):
    uuid = models.CharField(default=uuid4, unique=True, max_length=255)
    created_at = models.DateTimeField(auto_now_add=True, editable=False, null=True, verbose_name='Created at')
    updated_at = models.DateTimeField(auto_now=True, editable=False, null=True, verbose_name='Updated at')

    class Meta:
        abstract = True
        ordering = ('id',)
        get_latest_by = 'created_at'


class Book(BaseModel):
    name = models.CharField(max_length=255, verbose_name='Название книги')
    isbn = models.CharField(max_length=255, verbose_name='Код ISBN')
    author = models.CharField(max_length=255, verbose_name='Автор')
    published_year = models.IntegerField(verbose_name='Год выпуска')
    is_public = models.BooleanField(default=False, verbose_name='В публичном доступе?')
    document = models.FileField(
        validators=[FileExtensionValidator(['pdf', 'docx', 'epub', 'djvu'])], verbose_name='Файл')

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Книги'
        verbose_name_plural = 'Книги'

    def __str__(self):
        return self.name


class Link(BaseModel):
    name = models.CharField(max_length=255, verbose_name='Название статьи')
    link = models.TextField(max_length=255, verbose_name='Ссылка на источник')
    is_public = models.BooleanField(default=False, verbose_name='В публичном доступе?')

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Ссылки'
        verbose_name_plural = 'Ссылки'

    def __str__(self):
        return self.name


class Multimedia(BaseModel):
    name = models.CharField(max_length=255, verbose_name='Название мультимедии')
    file = models.FileField(verbose_name='Файл')
    is_public = models.BooleanField(default=False, verbose_name='В публичном доступе?')

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Мультимедия'
        verbose_name_plural = 'Мультимедия'

    def __str__(self):
        return self.name


class Software(BaseModel):
    name = models.CharField(max_length=255, verbose_name='Название программы')
    file = models.FileField(verbose_name='Файл')
    is_public = models.BooleanField(default=False, verbose_name='В публичном доступе?')

    class Meta:
        verbose_name = 'Программное обеспечение'
        verbose_name_plural = 'Программное обеспечение'

    def __str__(self):
        return self.name
