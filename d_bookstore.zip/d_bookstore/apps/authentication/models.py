import binascii
import os

from django.db import models
from django.utils.translation import ugettext as _
from django.contrib.auth.models import AbstractUser

from main.models import BaseModel


class User(AbstractUser):
    GENDER = (
        (1, 'Мужчина'),
        (0, 'Женщина')
    )

    group_number = models.CharField(max_length=255, null=True, verbose_name='Номер группы')
    gender = models.SmallIntegerField(choices=GENDER, null=True, verbose_name='Пол')
    last_activity = models.DateTimeField(null=True, blank=True, verbose_name=_('Последняя активность'))

    class Meta(AbstractUser.Meta):
        app_label = 'authentication'

    def __str__(self):
        return str(self.first_name + ' ' + self.last_name)


class UserInfo(BaseModel):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='info', verbose_name='Пользователь')
    address = models.TextField(verbose_name='Домашний адрес')
    work = models.TextField(verbose_name='Место работы')
    position = models.TextField(verbose_name='Должность')
    phone = models.CharField(max_length=255, verbose_name='Номер телефона')

    class Meta:
        verbose_name = 'Данные пользователя'
        verbose_name_plural = 'Данные пользователей'

    def __str__(self):
        return self.user.__str__()

