from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import ugettext_lazy as _

from .models import User, UserInfo


@admin.register(User)
class SimpleUserAdmin(UserAdmin):
    fieldsets = (
        (None, {'fields': ('username', 'password',)}),
        (_('Personal info'), {'fields': ('first_name', 'last_name', 'email', 'gender', 'group_number')}),
        (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password1', 'password2'),
        }),
    )

    list_display = ('username', 'email', 'first_name', 'last_name', 'gender', 'group_number', 'is_staff')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'groups')
    search_fields = ('username', 'first_name', 'last_name', 'email', 'group_number')
    ordering = ('username',)
    filter_horizontal = ('groups', 'user_permissions',)


@admin.register(UserInfo)
class UserInfoAdmin(admin.ModelAdmin):
    search_fields = ('address', 'work', 'position', 'phone')
    list_filter = ('user', 'address', 'work', 'position', 'phone')
    list_display = ('user', 'address', 'work', 'position', 'phone')
    fields = ('user', 'address', 'work', 'position', 'phone')

